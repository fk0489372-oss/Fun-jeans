# FUN JEANS Website

A responsive, GitHub Pages-ready static website for FUN JEANS.

## Files
- `index.html` — website structure
- `style.css` — responsive design
- `images/` — owner and jeans photos

## Run locally
Open `index.html` in a browser.

## GitHub Pages
1. Create a GitHub repository.
2. Upload `index.html`, `style.css`, and the `images` folder.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, select **Deploy from a branch**.
5. Select the `main` branch and `/ (root)`.
6. Save.

The phone buttons use `tel:` and WhatsApp uses the provided number.
